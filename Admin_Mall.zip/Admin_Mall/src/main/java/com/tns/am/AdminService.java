package com.tns.am;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;




@Service
@Transactional
public class AdminService {

	@Autowired
	private AdminRepository repo;
	
		public List<Admin> showAll(){
			return repo.findAll();
			
		}
	
	public Admin get(Integer id) {
		return repo.findById(id).get();
	}

	public void save(Admin admin) {
		repo.save(admin);
	}
	
	public void delete(Integer id) {
		repo.deleteById(id);
	}
	
}