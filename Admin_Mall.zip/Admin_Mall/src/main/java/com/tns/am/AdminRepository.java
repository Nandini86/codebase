package com.tns.am;
import org.springframework.data.jpa.repository.JpaRepository;

//Extending jpa repo for build-in methods for accessing DataBase
public interface AdminRepository extends JpaRepository<Admin, Integer>  {

}
