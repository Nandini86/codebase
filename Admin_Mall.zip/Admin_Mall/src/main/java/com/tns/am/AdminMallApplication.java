package com.tns.am;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminMallApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminMallApplication.class, args);
	}

}
