package com.tns.am;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
@CrossOrigin("http://localhost:3000")
public class AdminController {
	
	
	
	

	public AdminController(AdminService service, AdminRepository repository) {
		super();
		this.service = service;
		this.repository = repository;
	}


	private AdminService service;
	
	private AdminRepository repository;
	
	
	//Retrieval
	@GetMapping("/admins")
	public List<Admin> list(){
		return service.showAll();
		
	}
	
	//Retrieve By Id
	@GetMapping("/admins/{id}")
	public ResponseEntity<Admin> get(@PathVariable Integer id){
		try {
			if (!repository.existsById(id)) {
				throw new UsernameNotFoundException("User Doesn't Exist in Database");
				
			
			}
			Admin admin= service.get(id);
			return new ResponseEntity<Admin> (admin,HttpStatus.OK);
		} 
		catch (Exception e) {
			return new ResponseEntity<Admin> (HttpStatus.NOT_FOUND);
		}
	}//end of findByid()
		
	
	//Create
	@PostMapping("/admins")
	public void add(@RequestBody Admin admin) {
		service.save(admin);
	}
	
	
	
	
	//Update
	@PutMapping("/admins/{id}")
	public ResponseEntity<?> update(@RequestBody Admin admin, @PathVariable Integer id ){
		
		try {
			Admin existAdmin= service.get(id);
			service.save(admin);
			return new ResponseEntity<> (HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<> (HttpStatus.NOT_FOUND);
		}
		
	}//end of update()
	
	
	//Delete
	
	@DeleteMapping("/admins/{id}")
	public void delete(@PathVariable Integer id ) {
		service.delete(id);
	}
	
	
	
	
	
		
}
