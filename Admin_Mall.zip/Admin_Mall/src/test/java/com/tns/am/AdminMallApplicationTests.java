package com.tns.am;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminMallApplicationTests {
	
	@Autowired
	AdminRepository repository;

	@Test
	void contextLoads() {
		Admin admin=new Admin();
		admin.setId(1);
		admin.setMall("xxxx");
		admin.setName("vignesh");
		admin.setPhone("7894561231");
		admin.setPassword("4723#");
		repository.save(admin);	//saving into Db
		assertNotNull(repository.findById(1).get());
		
	}
		
	@Test	
	public void testReadAll() {	
	List<Admin> list=repository.findAll();
	assertThat(list).size().isGreaterThan(0);
	}
	
	@Test
	public void testSingleAdmin() {
    Admin admin=repository.findById(1).get();
	assertEquals("4723#",admin.getPassword());
		}
	@Test
     public void testUpdate() {
    	 Admin admin=repository.findById(1).get();
    	 admin.setPassword("@123");
    	 repository.save(admin);
    	 assertEquals("4723#", repository.findById(1).get().getPassword());
     }
	
	

	
}
